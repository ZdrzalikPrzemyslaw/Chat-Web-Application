package tech.czatmat.app.CzatMatApp.dataClasses.keys;

import org.springframework.data.repository.CrudRepository;

public interface KeysRepository extends CrudRepository<Key, Long> {
}
