package tech.czatmat.app.CzatMatApp.dataClasses.keys.keys_users;

import org.springframework.data.repository.CrudRepository;

public interface KeyUserRepository extends CrudRepository<KeyUser, Long> {
}
