# frontend

Projekt lokalnie skonfigurowany jest by korzystać z serwera hostowanego na http://localhost:8080/.
W celu zmiany konfiguracji należy zmienić zawartość pliku .env.development.

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

